<?php  

function deretBilanganPrima($bawah, $atas){

	echo "Batas bawah : $bawah <br>";
	echo "Batas atas : $atas <br>";
	echo "Deret bilangan prima : ";

	for($i=$bawah; $i <= $atas; $i++){

		// Variable Jumlah Pembagian
		$a = 0;

		// Menentukan Nilai Pembagi
		for($b = 1; $b <= $i; $b++){

			// Check Bilangan dengan melakukan Pembagian
			if($i % $b == 0){
				// Jika benar, tambah 1 jumlah pembagian
				$a++;
			}
		}

		// Jika Jumlah Pembagian Sebanyak 2x Tampilkan bilangan Prima
		if($a == 2){
			echo $i . ", ";
		}
	}

}

// Memanggil Fungsi
deretBilanganPrima(6, 20);

echo "<br><br>";

// Contoh 2
echo "Contoh Bilangan Prima kedua<br>";
deretBilanganPrima(24, 200);

?>