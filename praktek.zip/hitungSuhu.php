<?php

function hitungSuhu($data)
{

	// Hitung Banyak data
	$jumlah = count($data);
	// Hitung Rata Rata 
	$rata_rata = array_sum($data) / $jumlah;
	// Format Nilai rata-rata dengan dua angka dibelakang koma/titik
	$rata_rata = number_format($rata_rata, 2);
	// Hitung Data Terendah
	$min = min($data);
	// Hitung Data Tertinggi
	$max = max($data);

	echo "Suhu rata-rata : $rata_rata <br>";
	echo "Suhu terendah : $min <br>";
	echo "Suhu tertinggi : $max <br>";

}

function hitungSuhuDua($data)
{
	// Urutkan data dari terkecil
	sort($data);
	// Hitung Banyak data
	$jumlah = count($data);
	// Hitung Rata Rata 
	$rata_rata = array_sum($data) / $jumlah;
	// Format Nilai rata-rata dengan dua angka dibelakang koma/titik
	$rata_rata = number_format($rata_rata, 2);
	// Ambil data terkecil
	$min = $data[0];
	// Urutkan data dari terbesar
	rsort($data);
	// Ambil data terbesar
	$max = $data[0];

	echo "Suhu rata-rata : $rata_rata <br>";
	echo "Suhu terendah : $min <br>";
	echo "Suhu tertinggi : $max <br>";

}

$data = [
	37,
	30,
	28,
	33,
	29,
	34,
	27
];

// Menggunakan Cara Pertama
echo hitungSuhu($data);

echo "<br><br>";

// Menggunakan Cara Kedua
echo hitungSuhuDua($data);
