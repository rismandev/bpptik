<?php  

// Data Alas & Tinggi
$alas = 20;
$tinggi = 5;

// Rumus Luas Segitiga
$result = 0.5 * $alas * $tinggi;

// Tampilkan Alas & Tinggi
echo "Alas : $alas <br>";
echo "Tinggi : $tinggi <br>";

// Tampilkan Luas 
echo "Luas Segitiga : $result <br>";

?>