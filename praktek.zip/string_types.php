<?php  

$j = 5;
echo "<br>";
$info = 'Preface variables with a $ lke this: $j';
echo $info;
echo "<br>";
$info = "Preface variables with a $ like this: $j";
echo $info;


?>