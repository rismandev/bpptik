<?php  

$j = 3;
$k = 2;

echo $j == 3 && $k == 2;
echo "<br>";
echo $j < 5 || $k > 10;
echo "<br>";
echo !($j == $k);
echo "<br>";
$j = true;
$k = false;
echo $j xor $k;
echo "<br>";

?>