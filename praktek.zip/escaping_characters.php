<?php

echo "<br>";
$text = 'My spelling\'s atroshus';
echo $text;
echo "<br>";

echo "<br>";
$text = "She wrote upon it, \"Return to sender\".";
echo $text;
echo "<br>";

echo "<br>";
$heading = "Date\tName\tPayment";
echo $heading;
echo "<br>";

// Multiple-line Commands
echo "<br>";
$author = "Steve Ballmer";
echo "Developers, Developers, developers,
developers, developers,
developers, developers, developers, developers!

- $author.";
echo "<br>"; 