<?php 

$bensin = 10;
do{
	echo "Jalan Terus...<br>";
	$bensin--;
}while ($bensin > 0)

?>