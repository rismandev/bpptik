<?php  

echo "<br>";
$lampu = "Hijau";
if($lampu == "Hijau"){
	echo "Jalan";
}elseif($lampu == "Merah") {
	echo "Berhenti";
}else {
	echo "Hati-Hati";
}

?>