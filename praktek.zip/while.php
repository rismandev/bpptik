<?php 

$bensin = 10;
while ($bensin > 0) {
	echo "Jalan Terus...<br>";
	$bensin--;
}

?>