<?php

// Ascending
$colors = array("red", "green", "blue", "yellow");

sort($colors);

foreach ($colors as $value) {
	echo "$value <br>";
}

echo "<br> <br>";

// Descending
$colors = array("red", "green", "blue", "yellow");

rsort($colors);

foreach ($colors as $value) {
	echo "$value <br>";
}