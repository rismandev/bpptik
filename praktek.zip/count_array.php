<?php

$mobil = array("Datsun", "Daihatsu", "Toyota");
echo count($mobil);