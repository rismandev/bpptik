<?php

$motor[0] = "Honda";
$motor[1] = "Yamaha";
$motor[2] = "Suzuki";
echo "Saya suka motor " . $motor[0] . ", " . $motor[1] . ", dan " . $motor[2];
