<?php  

echo "<br>";
$j = 15;
echo $j += 5;
echo "<br>";
echo $j -= 3;
echo "<br>";
echo $j *= 8;
echo "<br>";
echo $j /= 16;
echo "<br>";
$k = 3;
echo $j .= $k;
echo "<br>";
echo $j %= 4;

?>