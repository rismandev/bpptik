<?php  

echo "<br>";
$angka = -1;
if($angka >= 0){
	echo "Bilangan Positif";
}else {
	echo "Bilangan Negatif";
}

?>