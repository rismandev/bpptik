<?php

// Tentukan Masukan
$n = 25;

// Buat Pengulangan dari 1 sampai sama dengan masukan
for($i = 1; $i <= $n; $i++){

	// Kalikan Hasil
	$angka = $i * $i;

	// Check hasil kali dengan Masukan
	if($angka == $n){
		// Jika benar maka Tampilkan
		echo "$i adalah akar bilangan bulat positif dari $n";
		// Set Agar tidak terjadi Pengulangan
		$i = $n;
	}elseif($i == $n){
		// Jika Pengulangan Habis artinya tidak memiliki bilangan bulat positif
		echo "$n tidak memiliki akar bilangan bulat positif";
	}

}

