<?php  

echo "<br>";
$msgs = 3;
echo "You have " . $msgs . " messages.";
echo "<br>";

echo "<br>";
$bulletin = "Dalam rangka mendukung program pengembangan sumber daya manusia, BPPTIK mengadakan FGD kurikulum pelatihan pada bidang IT Security. ";
$newflash = "FGD yang dilaksanakan di Pustiknas Kominfo tersebut dibuka oleh Kepala BPPTIK, Nusirwan";
$bulletin .= $newflash;
echo $bulletin;
echo "<br>";


?>