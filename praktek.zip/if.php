<?php  

echo "<br>";
$angka = 3;
if($angka >= 0){
	echo "Bilangan Positif";
}

?>