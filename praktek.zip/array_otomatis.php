<?php

$mobil = array("Datsun", "Daihatsu", "Toyota");
echo "Saya suka mobil " . $mobil[0] . ", " . $mobil[1] . ", dan " . $mobil[2];