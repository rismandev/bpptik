<?php

function luasPersegiPanjang($panjang, $lebar){

	$luas = $panjang * $lebar;

	return $luas;
}

echo "Luas Persegi Panjang : " . luasPersegiPanjang(4, 3);