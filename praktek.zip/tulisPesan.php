<?php

function tulisPesan(){

	echo "Halo Dunia!";

}

tulisPesan();