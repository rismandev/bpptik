<?php

// Otomatis
$age = array("Peter" => "35", "Ben" => "37", "Joe" => "43");
echo "Peter berusia " . $age['Peter'] . " tahun.";

echo "<br><br>";

// Manual
$height['Peter'] = "168";
$height['Ben'] = "178";
$height['Joe'] = "180";
echo "Ben tingginya " . $height['Ben'] . " cm.<br>";

// Pengulangan
foreach ($age as $x => $x_value) {
	echo "<br>";
	echo "Key= " . $x . ". Value " . $x_value;
}
