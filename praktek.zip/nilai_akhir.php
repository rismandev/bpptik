<?php  

// Data Nilai Ujian
$praktek = 85;
$ganda = 85;
$kehadiran = 80;
$sikap = 82;

// Rumus Hitung Nilai Akhir
$nilai_akhir = (0.6 * $praktek) + (0.3 * $ganda) + (0.05 * $kehadiran) + (0.05 * $sikap);

// Tampilkan Daftar Nilai
echo "Nilai Ujian Praktek : " . $praktek . "<br>";
echo "Nilai Ujian Pilihan Ganda : " . $ganda . "<br>";
echo "Nilai Kehadiran : " . $kehadiran . "<br>";
echo "Nilai Sikap : " . $sikap . "<br>";

// Tampilkan Nilai Akhir
echo "<br>Nilai Akhir : " . $nilai_akhir;

?>