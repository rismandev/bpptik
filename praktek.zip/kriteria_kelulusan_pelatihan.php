<?php

// Tentukan Nilai Akhir
$nilai_akhir = 100;
$kriteria = '';

if($nilai_akhir > 100 || $nilai_akhir < 0){
	echo "Input Nilai Akhir Salah / Tidak Valid<br>";
}else{
	// Kondisi Nilai Akhir
	if($nilai_akhir >= 95){
		$kriteria = 'Memuaskan';
	}elseif($nilai_akhir < 95 && $nilai_akhir >= 85){
		$kriteria = 'Baik Sekali';
	}elseif($nilai_akhir < 85 && $nilai_akhir >= 75){
		$kriteria = 'Baik';
	}elseif($nilai_akhir < 75 && $nilai_akhir >= 65){
		$kriteria = 'Cukup';
	}else{
		$kriteria = 'Tidak Lulus';
	}

}

// Nilai Akhir
echo "Nilai Akhir : $nilai_akhir <br>";

// Tampilkan Kriteria
echo "Kriteria : $kriteria";

?>