<?php  

$j = 4;
echo $j == 4;
echo "<br>";
echo $j != 21;
echo "<br>";
echo $j > 3;
echo "<br>";
echo $j < 100;
echo "<br>";
echo $j >= 15;
echo "<br>";
echo $j <= 8;
echo "<br>";

echo "----------";

$j = 50;
echo $j == 4;
echo "<br>";
echo $j != 21;
echo "<br>";
echo $j > 3;
echo "<br>";
echo $j < 100;
echo "<br>";
echo $j >= 15;
echo "<br>";
echo $j <= 8;
echo "<br>";

?>