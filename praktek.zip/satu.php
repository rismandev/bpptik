<?php  

	echo "Hallo Dunia!";

	//	Komentar

	/*	Komentar
		lebih dari
		satu baris	*/

//	Mencetak Variable String
	echo "<br>";
$username = "Fred Smith";
	echo $username;
	echo "<br>";
$current_user = $username;
	echo $current_user;
	echo "<br>";

//	Mencetak Numerik dan Desimal
	echo "<br>";
$count = 17;
	echo $count;
	echo "<br>";
$count = 17.5;
	echo $count;
	echo "<br>";

//	Operator Arithmetic
	echo "<br>";
$j = 10;
	echo $j + 1;
	echo "<br>";
	echo $j - 6;
	echo "<br>";
	echo $j * 11;
	echo "<br>";
	echo $j / 4;
	echo "<br>";
	echo $j % 9;
	echo "<br>";
	echo ++$j;
	echo "<br>";
	echo --$j;
	echo "<br>";

?>